declare module "node-forge";
